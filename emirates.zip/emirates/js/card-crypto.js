const cryptoName = document.querySelectorAll(".crypto__name");
const cryptoPrice = $(".crypto__cost");
const cryptoRating = $(".crypto__rate");

var card = {
  name: "",
  price: "",
  rating: "",
};

fetch(
  "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=binancecoin%2Csolana%2Cethereum%2Cbitcoin%2Ccardano%2Cdogecoin%2Ctether%2Cusd-coin%2Cripple&order=market_cap_desc&per_page=100&page=1&sparkline=false"
)
  .then((response) => response.json())
  .then((data) => {
    data.forEach((elem) => {
   
      cryptoName.forEach((title) => {
        let attr = title.dataset.name;
        if (attr === elem.id) {
          card.name = elem.name;
          card.price = elem.current_price;
          card.rating = parseFloat(elem.price_change_percentage_24h).toFixed(2);
          console.log(card);
        }
      });
      // for (let i = 0; i <= cryptoName.length; i++) {
      //   let attr = cryptoName[i].attr('data-name');
      //   if (attr === elem.id) {
      //     cryptoName[i].innerHTML = elem.name;
      //   }
      // }
    });
  });
